package com.example.alvarog.lapractica;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Registro extends AppCompatActivity {



    EditText meteremail;
    EditText contrasena;
    //Button Bentrar;

    String username;
    String contrasenya;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);

        meteremail = (EditText) findViewById(R.id.entraemail);
        contrasena=(EditText) findViewById(R.id.entracontrasena);
        //Bentrar= (Button) findViewById(R.id.Bentrar);
        //Ahora la base de datos se inicia en LapracticaMain, debo probar si se siguen registrando los nuevos usuarios introducidos
        //LapracticaMain.miBD = new Mibasededatos(this, "otraBD", null, 1);
    }

    //toma los valores de los campos de email y contraseña y los registra en la base de datos
    public void meterdatos(View papito){
        username=meteremail.getText().toString();
        contrasenya=contrasena.getText().toString();
        LapracticaMain.miBD.insertar(username, contrasenya);
    }

    //Manda al usuario a la pantalla de inicio
    public void alinicio (View view){

        Intent intent = new Intent(this, LapracticaMain.class);
        Button editText = (Button) findViewById(R.id.Bvolver);
        startActivity(intent);
    }

    public void comparardatos (View view){

        username=meteremail.getText().toString();
        contrasenya=contrasena.getText().toString();
        String emcorrecto = getResources().getString(R.string.email);
        String pacorrecto = getResources().getString(R.string.password);
        String emailescrito;
        String contrasenaescrita;
        emailescrito = username;
        contrasenaescrita= contrasenya;

        if (emailescrito.equals(emcorrecto) && contrasenaescrita.equals(pacorrecto)){
            System.out.println("correcto");
            Toast.makeText(this, "Correcto", Toast.LENGTH_SHORT).show();
        }
        else{
            System.out.println("incorrecto");
            Toast.makeText(this, "Falla", Toast.LENGTH_SHORT).show();
        }
    }

}
