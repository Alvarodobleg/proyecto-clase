package com.example.alvarog.lapractica;

import android.content.Intent;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import static android.provider.AlarmClock.EXTRA_MESSAGE;

public class inicionext extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inicionext);

        ConstraintLayout fondoinicio = findViewById(R.id.inicioLayout);

        if (LapracticaMain.fondodianoche==false){
            fondoinicio.setBackgroundResource(R.drawable.day);
        }
        else{
            fondoinicio.setBackgroundResource(R.drawable.night);
        }
        /*Bundle extras = getIntent().getExtras();
        if (extras != null) {
            int valordepantallaanterior = extras.getInt("fondoback");

            //The key argument here must match that used in the other activity
            fondoinicio.setBackgroundResource(R.drawable.day);
        } */

    }

    //Al pulsar el botón salir devuelve al usuario a la pantalla de inicio
    public void alinicio (View view){

        Intent intent = new Intent(this, LapracticaMain.class);
        Button editText = (Button) findViewById(R.id.pafuera);
        startActivity(intent);
    }

    public void apersonaje (View view){

        Intent intent = new Intent(this, listapj.class);
        Button editText = (Button) findViewById(R.id.personajelist);
        startActivity(intent);
    }
}
