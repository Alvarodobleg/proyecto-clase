package com.example.alvarog.lapractica;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class listapj extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listapj);
    }

    public void alPersonaje (View view){

        Intent intent = new Intent(this, LapracticaMain.class);
        Button editText = (Button) findViewById(R.id.pafuera);
        startActivity(intent);
    }
}
