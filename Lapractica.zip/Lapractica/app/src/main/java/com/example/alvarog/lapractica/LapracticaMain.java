package com.example.alvarog.lapractica;

import android.content.Intent;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.app.AppCompatDelegate;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.Toast;
import android.widget.ToggleButton;

import static android.provider.AlarmClock.EXTRA_MESSAGE;

public class LapracticaMain extends AppCompatActivity {
    //ariable de la clase Mibasededatos que crea la base de datos que utilizaremos en toda la aplicación mientras corresponda
    public static Mibasededatos miBD;
    EditText usuario;
    EditText pass;
    boolean logeado=false;
    String usuarioStr;
    String passStr;
    ConstraintLayout fondo;
    static boolean fondodianoche=true;

    //En el OnCreate se cra la instancia y se inicializan los elemento que se van a utilizar dentro de esta pantalla
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lapractica_main);
        usuario = (EditText) findViewById(R.id.usuarioMain);
        pass=(EditText) findViewById(R.id.passMain);
        miBD = new Mibasededatos(this, "otraBD", null, 1);

        ToggleButton toggle = (ToggleButton) findViewById(R.id.toggleButton2);
        toggle.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                fondo = findViewById(R.id.LayoutMain);
                if (isChecked) {
                    fondodianoche=false;
                    fondo.setBackgroundResource(R.drawable.day);
                } else {
                    fondodianoche=true;
                    fondo.setBackgroundResource(R.drawable.night);
                }
            }
        });

        fondo = findViewById(R.id.LayoutMain);

        if (LapracticaMain.fondodianoche==false){
            fondo.setBackgroundResource(R.drawable.day);
        }
        else{
            fondo.setBackgroundResource(R.drawable.night);
        }

    }
    //Método que manda al usuario a iniciotext al pulsar el botón Inicio
    /*public void otrapantalla (View view){

        Intent intent = new Intent(this,inicionext.class);
        Button editText = (Button) findViewById(R.id.inicio);
        String message = editText.getText().toString();
        intent.putExtra(EXTRA_MESSAGE, message);
        startActivity(intent);
    }^*/

    //Método que manda al usuario a Registro al pulsar el botón registro
    public void alregistro (View view){

        Intent intent = new Intent(this,Registro.class);
        Button editText = (Button) findViewById(R.id.Bregistro);
        String message = editText.getText().toString();
        intent.putExtra(EXTRA_MESSAGE, message);
        startActivity(intent);
    }

    /*Cuando se introducen unos datos en los campos de usuario y contraseña al pulsar el botón LOGIN pasará el valor en String de
    los campos a la función y comparará el usuario y la contraseña con los que hay guardados en la base de datos, en caso de que
    encuentre estos datos en la base de datos pasará al usuario a la siguiente pantalla que de momento es iniciotext, aunque se cambiará en algún momento*/
    public void logearse(View view){

        usuarioStr=usuario.getText().toString();
        passStr=pass.getText().toString();
        logeado=miBD.consulta(usuarioStr,passStr);
        String fondoimg = "R.drawable.day";
        int idFondo = R.drawable.day;


        if (logeado==true){

            Intent intent= new Intent(this,inicionext.class);
            intent.putExtra("fondoback",idFondo);
            startActivity(intent);
        }
        else{
            Toast.makeText(this, "Falla", Toast.LENGTH_SHORT).show();
        }
    }


}
