package com.example.alvarog.lapractica;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.annotation.Nullable;
import android.view.View;


public class Mibasededatos extends SQLiteOpenHelper {

    String sql="CREATE TABLE Usuario (Nombre TEXT PRIMARY KEY , Pass TEXT)";

    public Mibasededatos(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS Usuario");
        db.execSQL(sql);
    }


    public void insertar(String meteremail, String contrasena){


        if (meteremail.length()>0 && contrasena.length()>0){
            SQLiteDatabase db = LapracticaMain.miBD.getWritableDatabase();

            db.execSQL("INSERT INTO Usuario (Nombre, Pass) VALUES('"+ meteremail+"','" + contrasena+"' )");
            db.close();
        }
    }

    public boolean consulta(String mail, String password){

        SQLiteDatabase db = LapracticaMain.miBD.getReadableDatabase();

        Cursor cursor=db.rawQuery("SELECT Nombre, Pass FROM Usuario WHERE Nombre = '"+mail+"' AND Pass = '"+password+"'",null);

        return cursor.moveToNext();
    }
}
