package notfireemblem;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;


public class Selector {
    
    static boolean parra=false;
    
    int movilidad=1;
    int movilidadGuardada;
    boolean movimiento=false;
    boolean pulsado=false;
    int x=0;
    int y=0;
    int xg;
    int yg;
    int tamañoMapa;

    // AHORA TOCA HACER QUE CUANDO LAS UNIDADES SE MUEVAN PONGAN UNA 'P' EN EL MAPA
    //LO QUE PASA ES QUE AL DIBUJAR EL SELECTOR Y ESCRIBIRLO EN EL MAPA PARA SABER SU POSICIÓN CUANDO SE PONE ENCIMA DE LA 'P' ESAS P SE PIERDEN Y SE BORRAN POR ESO LUEGO NO SALEN MÁS
    public Selector(int tamañoMapa,int x, int y){
        
        this.movilidadGuardada=movilidad;
        this.tamañoMapa=tamañoMapa;
        this.x=x*30;
        this.y=y*30;
        this.xg=x/30;
        this.yg=y/30;
  
    }
    
    public int moveselector(char mapa[][], int numerounidad, Unidades unidad[]) {   
        //esta variable controla que cuando se pulse 'z' en el movimiento de la unidad se pueda volver a mover el selector
        //ya que si no está esta condición detectará que hay una 'U' en la posición de selector y nunca se podrá cambiar de unidad
        if(parra==false){     
            if(movimiento==false){ 
            //Si es selector se encuentra con un protagonista
            if(mapa[x/30][y/30]=='U'){ 
               //Si encuentre la 'P' busca en todas las unidades para saber cual es la que tiene esas coordenadas
               //y tomar su numerounidad para seleccionarla a la hora de mover
                for (int i = 0; i < unidad.length; i++) {

                        if (this.x==unidad[i].x && this.y==unidad[i].y) {
                            numerounidad=unidad[i].numerounidad;
                        }                
                    }
                }      

               /* mapa[x/30][y/30]='S';
                mapa[xg][yg]='■';

                xg=x/30;
                yg=y/30;*/

            }
        }
        //Devuelve el valor de numerounidad para que se seleccione correctamente cual se moverá 
        return numerounidad;
     }
    public void paint2(Graphics2D g) {
        if(movimiento==true){
            Color colorselector=new Color (255,255,0,100);
            g.setColor(colorselector);
            g.fillRect(x-3, y-3, 30, 30);
        }
    }
    public void paint(Graphics2D g) {
        
        
        if(movimiento==true){
            g.setColor(Color.DARK_GRAY);
            g.fillRect(x, y, 30, 30);
            
                       
        }
        else{
            Color colorselector=new Color (255,255,0,100);
            g.setColor(colorselector);
            g.fillRect(x+1, y+1, 29, 29);
        }
        
    }
    
    public void keyPressed(KeyEvent e) {
        
        if (e.getKeyCode() == KeyEvent.VK_X){
            if(pulsado==false){
                movimiento=true;
            }
            else{
                movimiento=false;
                parra=false;
                movilidad=movilidadGuardada;
            }
        }
        if(movimiento==true){
           
            if (e.getKeyCode() == KeyEvent.VK_UP){
                if(y>0)
                    if(movilidad!=0){
                        y-=30;                       
                    }
                    
            }
            if (e.getKeyCode() == KeyEvent.VK_DOWN){
                if(y<(tamañoMapa-1)*30)
                    if(movilidad!=0){
                        y+=30;
                    }
            }
            if (e.getKeyCode() == KeyEvent.VK_RIGHT){
                if(x<(tamañoMapa-1)*30)
                    if(movilidad!=0){
                        x+=30;
                    }
            }
            if (e.getKeyCode() == KeyEvent.VK_LEFT){
                if(x>0)
                    if(movilidad!=0){
                        x-=30;
                    }
            }
        }
        
    }
    
    public void keyReleased(KeyEvent e) {
        if(movimiento==true){
            pulsado=true;
        }
        else{
            pulsado=false;
        }
    }
    
}
