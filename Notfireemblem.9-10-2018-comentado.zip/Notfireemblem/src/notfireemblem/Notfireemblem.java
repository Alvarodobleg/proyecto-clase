package notfireemblem;

import javax.swing.JFrame;

class Notfireemblem {

    
    public static void main(String[] args) throws InterruptedException {
        
        JFrame frame = new JFrame("Proyecto");
        Game game = new Game();
        
        
        frame.add(game);
        frame.setSize(game.tamañoMapa*30+7, game.tamañoMapa*30+30);
        frame.setVisible(true);
        frame.setResizable(false);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        while (true) {
            game.moveselector();
            game.repaint();
            //Thread.sleep(10);     
        }
    }
    
}
