package notfireemblem;

import static com.sun.java.accessibility.util.AWTEventMonitor.addKeyListener;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import static notfireemblem.Game.selectormove;


public class Unidades {
    
    int movilidad;
    int movilidadGuardada;
    boolean movimiento=false;
    /*En la mayoría de los casos x, y tienen un valor multiplicado por 30, siendo estos 30 los píxeles que ocupará el dibujo a la hora de pintarlos
    mientras que xg,yg tiene dos funcionalidades según el momento, pueden tener el valor de x e y dividido entre 30, lo que vendría a ser su posición en el array,
    o tener el valor de la posición anterior al momento de moverse*/
    int x=0;
    int y=0;
    int xg;
    int yg;
    int tamañoMapa;
    int numerounidad;
    //desplazado indica si la unidad se ha movido o no
    boolean desplazado;
    
    
    
    public Unidades(int tamañoMapa,int x, int y,int numeroprotagonista){
        
        this.movilidad=5;
        this.movilidadGuardada=movilidad;
        this.tamañoMapa=tamañoMapa;
        this.x=x*30;
        this.y=y*30;
        this.xg=this.x/30;
        this.yg=this.y/30;
        System.out.println(xg+"  "+yg); 
        System.out.println(this.x+"  a "+this.y);
        //Su posicion en el array es su número definitorio a la hora de ver cual mover
        this.numerounidad=numeroprotagonista;
        
        this.desplazado=false;
    }
    
    public void move() {
        if( desplazado==true){
            /*en el momento que desplazado==true y la unidad se haya movido se reinicia su movilidad para el siguiente movimiento
            
            se devuelve el movimiento al selector dando a selectormove el valor de true, y el numerounidad a -1 para que no entre a
            ninguna unidad no deseada en ese moento (la unidad nunca podrá tener valor -1 asi que es un valor de reinicio seguro)
            */
            movilidad=movilidadGuardada;
            movimiento=false;
            Game.selectormove=true;
            Game.numerounidad=-1;
            Selector.parra=true;
        }
     }
    
    public void paint(Graphics2D g) {
        //movimiento unidades
        if(movimiento==true && Game.numerounidad!=-1){
            g.setColor(Color.blue);
            g.drawRect(x, y, 30, 30);
            //cuando se levanta se iluminan las casillas de donde te puedes mover
            for (int i = 1; i <= movilidad; i++) {
                g.drawRect(x+(i*30), y, 30, 30);
                g.drawRect(x, y+(i*30), 30, 30);
                g.drawRect(x-(i*30), y, 30, 30);
                g.drawRect(x, y-(i*30), 30, 30);
            }
            //Cuando seleccionas una unidad hace el efecto de levantarse
            g.setColor(Color.darkGray);
            g.fillOval(x+1, y+1, 29, 29);
            g.setColor(Color.BLUE);
            g.fillOval(x+1, y+1-5, 29, 29);            
        }
        else if (movimiento==true && Game.numerounidad==-1 ) {
                g.setColor(Color.BLUE);
                g.fillOval(x, y, 30, 30);
            }
        
        else{
            g.setColor(Color.BLUE);
            g.fillOval(x+1, y+1, 29, 29);
            //Cuando desplazado(que indica que se ha movido) es true, se pone color negro para confirmar visualmente que se ha movido
            if (desplazado==true) {
                g.setColor(Color.BLACK);
                g.fillOval(x+1, y+1, 29, 29);
            }
        }
        
        
    }
    //keyPressed se activa en el momento que se pulsa la tecla
    public void keyPressed(KeyEvent e) {
       //Cuando el botón pulsado es el espacio y la unidad no se ha movido(desplazado==false) 
        if (e.getKeyCode() == KeyEvent.VK_SPACE && desplazado==false){
            //En principio nada más pulsa el botón pulsado es false y entrará en este if
            
            if(movimiento==false ){//&& Game.selectormove==false
                /*movimiento toma el valor true para permitir el movimiento con las teclas de movimiento y la z
                además influye en el metodo paint para que se pinta una representación correcta de lo que ocurre en ese moemtno*/
                movimiento=true;
                //esots systemout son comprobantes
                System.out.println(x+"  "+y);  
                System.out.println(xg+"  "+yg); 
            }
            //si la casilla a la que se va a mover está vacía y además se ha movido de su posición entrará en este else if
            else if(Game.mapa[x/30][y/30]=='■' && movilidad!=movilidadGuardada){
                //movimiento==false para reiniciar el valor
                movimiento=false;
                //la posición anterior guardada en xg, yg se pone en blanco
                Game.mapa[xg][yg]='■';
                /*en la nueva posición se situa la unidad dentro del mapa (la x,y suele star multiplicada por 30 para que los dibujos que se pinten
                en el tablero cuadren, como aquí queremos su posición en el mapa se divide entre 30 para sacar su posición real)*/
                Game.mapa[x/30][y/30]='U';
                //Comprobantes de que todo va bien con las posiciones
                System.out.println(x+"  "+y);  
                System.out.println(xg+"  "+yg); 
                //La posición guardada toma el valor de la posición actual
                xg=x/30;
                yg=y/30;
                //Pone el selectormove en valor true para que el krylistener cambie a la opción de las unidades al selector de nuevo
                Game.selectormove=true;
                Game.numerounidad=-1;
                this.setDesplazado(true);
                movilidad=movilidadGuardada;

            }
        }
        
        
        if(movimiento==true && Game.numerounidad!=-1){
            
            if (e.getKeyCode() == KeyEvent.VK_Z){                
                    x=xg*30;
                    y=yg*30;
                    movilidad=movilidadGuardada;
                    movimiento=false;
                    Game.selectormove=true;
                    Game.numerounidad=-1;
                    Selector.parra=true;
                }
             
            if (e.getKeyCode() == KeyEvent.VK_UP){
                if(y>0)
                    if(movilidad!=0){
                        y-=30;
                        movilidad--;
                    }
                    
            }
            if (e.getKeyCode() == KeyEvent.VK_DOWN){
                if(y<(tamañoMapa-1)*30)
                    if(movilidad!=0){
                        y+=30;
                        movilidad--;
                    }
            }
            if (e.getKeyCode() == KeyEvent.VK_RIGHT){
                if(x<(tamañoMapa-1)*30)
                    if(movilidad!=0){
                        x+=30;
                        movilidad--;
                    }
            }
            if (e.getKeyCode() == KeyEvent.VK_LEFT){
                if(x>0)
                    if(movilidad!=0){
                        x-=30;
                        movilidad--;
                    }
            }
        }
        
    }
    // keyReleased se ejecuta cuando levantar el dedo del botón
    public void keyReleased(KeyEvent e) {
        /*if(movimiento==true){
            pulsado=true;
        }
        else{
            pulsado=false;
        }*/
    }
    
    public boolean isDesplazado() {
        return desplazado;
    }

    public void setDesplazado(boolean desplazado) {
        this.desplazado = desplazado;
    }
   
    public int getMovilidad() {
        return movilidad;
    }

    public void setMovilidad(int movilidad) {
        this.movilidad = movilidad;
    }

    public int getMovilidadGuardada() {
        return movilidadGuardada;
    }

    public void setMovilidadGuardada(int movilidadGuardada) {
        this.movilidadGuardada = movilidadGuardada;
    }

    public boolean isMovimiento() {
        return movimiento;
    }

    public void setMovimiento(boolean movimiento) {
        this.movimiento = movimiento;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public int getXg() {
        return xg;
    }

    public void setXg(int xg) {
        this.xg = xg;
    }

    public int getYg() {
        return yg;
    }

    public void setYg(int yg) {
        this.yg = yg;
    }

    public int getTamañoMapa() {
        return tamañoMapa;
    }

    public void setTamañoMapa(int tamañoMapa) {
        this.tamañoMapa = tamañoMapa;
    }

    public int getNumerounidad() {
        return numerounidad;
    }

    public void setNumerounidad(int numerounidad) {
        this.numerounidad = numerounidad;
    }
       
}
