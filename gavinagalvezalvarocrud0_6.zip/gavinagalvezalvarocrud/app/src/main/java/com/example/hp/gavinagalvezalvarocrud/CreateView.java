package com.example.hp.gavinagalvezalvarocrud;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;

import modelo.Producto;
import modelo.ProductoDAO;

public class CreateView extends AppCompatActivity {

    ProductoDAO invocadorFunciones;
    EditText codigo;
    EditText nombre;
    EditText descripcion;
    EditText fecha;
    Producto crearProducto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.create_product);
        crearProducto =  new Producto();
        codigo = (EditText) findViewById(R.id.mdfCodigo);
        nombre = (EditText) findViewById(R.id.mdfNombre);
        descripcion = (EditText) findViewById(R.id.mdfDescripcion);
        fecha = (EditText) findViewById(R.id.mdfFecha);
        invocadorFunciones = new ProductoDAO(ProductoView.mibd.getWritableDatabase());

    }

    public void insertarProductoAlPulsar(View view) {

        crearProducto.setCodigo(codigo.getText().toString());
        crearProducto.setNombre(nombre.getText().toString());
        crearProducto.setDescripcion(descripcion.getText().toString());
        crearProducto.setFecha(fecha.getText().toString());
        //FALTA LA IMAGEN
        crearProducto.setImagen("1");
        invocadorFunciones.createProduct(crearProducto);
        Intent intent = new Intent(this,ProductoView.class);
        startActivity(intent);
    }
}
