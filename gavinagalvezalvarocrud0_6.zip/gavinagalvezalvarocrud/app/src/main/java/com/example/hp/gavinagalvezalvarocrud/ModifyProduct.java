package com.example.hp.gavinagalvezalvarocrud;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;

import modelo.BaseDatos;
import modelo.Producto;
import modelo.ProductoDAO;

public class ModifyProduct extends AppCompatActivity {

    ProductoDAO invocadorFunciones;
    EditText codigo;
    EditText nombre;
    EditText descripcion;
    EditText fecha;
    Producto modificarProducto;
    String[]seleccion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.modify_product);

        String clavePrimaria= getIntent().getStringExtra("miClave");
        codigo = (EditText) findViewById(R.id.mdfCodigo);
        nombre = (EditText) findViewById(R.id.mdfNombre);
        descripcion = (EditText) findViewById(R.id.mdfDescripcion);
        fecha = (EditText) findViewById(R.id.mdfFecha);

        SQLiteDatabase db = ProductoView.mibd.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM Producto WHERE codigo = '"+ clavePrimaria +"'", null);

        cursor.moveToFirst();
        codigo.setText(cursor.getString(0));
        nombre.setText(cursor.getString(1));
        descripcion.setText(cursor.getString(2));
        fecha.setText(cursor.getString(3));

        invocadorFunciones = new ProductoDAO(ProductoView.mibd.getWritableDatabase());

    }

    public void modificarAlPulsar(View view) {
        modificarProducto.setCodigo(codigo.getText().toString());
        modificarProducto.setNombre(nombre.getText().toString());
        modificarProducto.setDescripcion(descripcion.getText().toString());
        modificarProducto.setFecha(fecha.getText().toString());
        //FALTA LA IMAGEN
        modificarProducto.setImagen("1");
        invocadorFunciones.updateProduct(modificarProducto);
        Intent intent = new Intent(this,ProductoView.class);
        startActivity(intent);
    }
}
