package com.example.hp.gavinagalvezalvarocrud;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import java.util.ArrayList;
import java.util.Date;

import controlador.ProductControler;
import modelo.BaseDatos;
import modelo.Producto;

import static android.provider.AlarmClock.EXTRA_MESSAGE;

public class ProductoView extends AppCompatActivity {

    public static BaseDatos mibd;
    public static int posicion;
    Producto producto;
    ArrayList<Producto> listProducto;
    RecyclerView recycler;
    ImageButton btnEditProduct;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listProducto = new ArrayList<>();
        posicion=0;

        mibd = new BaseDatos(this, "productoBD", null, 6);
        iniciarProductos();
    }

    public void iniciarProductos() {

        //Asociar los valores de la base de datos con esto, con un for como limite el tamaño encontrar una forma de asociar el primer registro de la base con la primera posicion de los arrays
        //mirar bien lo de la fecha
        Cursor cursor = mibd.iniciarCursor();
        int pos=0;
        if (cursor.moveToFirst()) {
            while (!cursor.isAfterLast()) {
                String codigo = (cursor.getString(0));
                String nombre = (cursor.getString(1));
                String descripcion = (cursor.getString(2));
                String fecha = (cursor.getString(3));
                String imagen = (cursor.getString(4));
                producto = new Producto(codigo,nombre,descripcion,fecha,imagen);
                listProducto.add(producto);
                cursor.moveToNext();
                pos ++;
            }
        }
        iniciarRecycled();
    }

    public void iniciarRecycled(){

        recycler = (RecyclerView) findViewById(R.id.recycledid);
        ProductControler controler=new ProductControler(listProducto);
        recycler.setAdapter(controler);
        recycler.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false));
    }

    public void goToCreateProduct (View view){

        Intent intent = new Intent(this,CreateView.class);
        startActivity(intent);
    }

    public void irAModificarProducto(View view){

        Intent intent = new Intent(this,ModifyProduct.class);
        btnEditProduct = (ImageButton) findViewById(R.id.btnIrAEditar);
        intent.putExtra("miClave", listProducto.get(posicion).getCodigo());
        startActivity(intent);
    }
}
