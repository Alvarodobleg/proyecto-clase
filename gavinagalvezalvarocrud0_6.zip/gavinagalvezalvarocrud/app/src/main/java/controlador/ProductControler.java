package controlador;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import com.example.hp.gavinagalvezalvarocrud.R;

import java.util.ArrayList;

import modelo.Producto;
import modelo.ProductoDAO;

import static com.example.hp.gavinagalvezalvarocrud.ProductoView.posicion;

public class ProductControler extends RecyclerView.Adapter<ProductControler.ViewHolderDatos>{

    ArrayList<Producto> listProducto;

    public ProductControler(ArrayList<Producto> productoRecibido) {
        listProducto=productoRecibido;
    }

    @NonNull
    @Override
    public ViewHolderDatos onCreateViewHolder(ViewGroup parent, int viewtype) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.product_list,null,false);
        return new ViewHolderDatos(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolderDatos holder, int position) {

        holder.codigo.setText(listProducto.get(position).getCodigo());
        holder.nombre.setText(listProducto.get(position).getNombre());
        holder.descripcion.setText(listProducto.get(position).getDescripcion());
        holder.fecha.setText(listProducto.get(position).getFecha());
        //FALTA IMAGEN
    }

    @Override
    public int getItemCount() {
        return listProducto.size();
    }

    public class ViewHolderDatos extends RecyclerView.ViewHolder {

        TextView codigo;
        TextView nombre;
        TextView descripcion;
        TextView fecha;
        ImageButton btnEditar;
        ImageButton btnEliminarProduct;

        public ViewHolderDatos(@NonNull View itemView) {
            super(itemView);
            codigo = (TextView) itemView.findViewById(R.id.txtCodigo);
            nombre = (TextView) itemView.findViewById(R.id.txtNombre);
            descripcion = (TextView) itemView.findViewById(R.id.txtDescripcion);
            fecha = (TextView) itemView.findViewById(R.id.txtFecha);
            btnEliminarProduct = (ImageButton) itemView.findViewById(R.id.btnEliminar);
            btnEditar = (ImageButton) itemView.findViewById(R.id.btnIrAEditar);
            btnEliminarProduct.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //llamar al borrar
                    ProductoDAO proDAO = new ProductoDAO();
                    Producto productoPosicion = listProducto.get(getLayoutPosition());
                    String[] codigoEliminar = new String [] {productoPosicion.getCodigo()};
                    proDAO.deleteProduct(codigoEliminar);
                }
            });

            btnEditar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    posicion=getLayoutPosition();
                }
            });
            //btnEditProduct.setOnClickListener();
        }

        public void onClick(View v){

        }
    }
}
