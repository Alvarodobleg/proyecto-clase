package modelo;

import java.util.Date;

public interface IProductoDAO {

    public void createProduct(Producto productoCreado);
    public void readProduct();
    public void updateProduct(Producto productoModificado);
    public void deleteProduct(String[] codigo);

}
