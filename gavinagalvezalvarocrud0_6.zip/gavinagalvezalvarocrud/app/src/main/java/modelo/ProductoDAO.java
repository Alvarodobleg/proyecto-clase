package modelo;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;

import com.example.hp.gavinagalvezalvarocrud.ProductoView;
import static com.example.hp.gavinagalvezalvarocrud.ProductoView.mibd;


public class ProductoDAO extends ProductoView implements IProductoDAO{


    public ProductoDAO(SQLiteDatabase db) {
        SQLiteDatabase base = db;
    }
    public ProductoDAO(){}

    @Override
    public void createProduct(Producto productoCreado) {

        SQLiteDatabase base = ProductoView.mibd.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("codigo",productoCreado.getCodigo());
        cv.put("nombre",productoCreado.getNombre());
        cv.put("descripcion",productoCreado.getDescripcion());
        cv.put("fecha",productoCreado.getFecha());
        cv.put("imagen",productoCreado.getImagen());
        base.insert("Producto", null, cv);
    }

    @Override
    public void readProduct() {

    }

    @Override
    public void updateProduct(Producto productoModificado) {

        //mibd.modificarProducto(codigo,nombre,descripcion,fecha,imagen,code);
        SQLiteDatabase db = ProductoView.mibd.getReadableDatabase();
        System.out.println("AQUIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII");
        System.out.println(productoModificado.getCodigo() + "  " + productoModificado.getNombre() + "  " + productoModificado.getDescripcion());
        String coidgoAnterior=productoModificado.getCodigo();
        ContentValues cv = new ContentValues();
        cv.put("codigo",productoModificado.getCodigo());
        cv.put("nombre",productoModificado.getNombre());
        cv.put("descripcion",productoModificado.getDescripcion());
        cv.put("fecha",productoModificado.getFecha());
        cv.put("imagen",productoModificado.getImagen());

        db.update("Producto", cv, "codigo="+coidgoAnterior, null);
    }

    @Override
    public void deleteProduct(String[] codigo) {

        //mibd.borrarProducto(codigo);
        //Borra un registro de la tabla Producto donde el campo código es igual al valor transmitido por el String[] code
        SQLiteDatabase db = ProductoView.mibd.getWritableDatabase();
        db.delete("Producto","codigo=?",codigo);
    }
}
