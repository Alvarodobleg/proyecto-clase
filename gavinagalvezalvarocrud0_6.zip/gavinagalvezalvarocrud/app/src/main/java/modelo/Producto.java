package modelo;

import java.util.Date;

public class Producto {

    private String codigo;
    private String nombre;
    private String descripcion;
    private String fecha;
    private String imagen;

    public Producto(){

    }
    public Producto (String code, String name, String descr, String date, String image){

        this.codigo=code;
        this.nombre=name;
        this.descripcion=descr;
        this.fecha=date;
        this.imagen=image;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getImagen() {
        return imagen;
    }

    public void setImagen(String imagen) {
        this.imagen = imagen;
    }
}
