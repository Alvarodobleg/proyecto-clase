package modelo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.annotation.Nullable;

import com.example.hp.gavinagalvezalvarocrud.ProductoView;

import java.util.Date;

public class BaseDatos extends SQLiteOpenHelper {

    //Utilizando sqlite creamos las dor tablas que utilizaremos en la aplicación
    String Producto="CREATE TABLE Producto (codigo TEXT PRIMARY KEY , nombre TEXT, descripcion TEXT, fecha TEXT, imagen TEXT)";

    String sentencia="INSERT INTO Producto (codigo, nombre, descripcion, fecha, imagen) " +
            "VALUES('001','Plato de comer','UN plato, para comer la comida','06/09/1999','img1'),"+
                  "('002','Bobobo','El liberta cabelleras','08/08/2008','img1')";

    /**
     * Instantiates a new Mibasededatos.
     *
     * @param context the context
     * @param name    the name
     * @param factory the factory
     * @param version the version
     */
//Constructor de la base de datos
    public BaseDatos(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    //Elementos creados en  la base de datos,los cuales son las tablas y la sentencia que inserta los datos
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(Producto);
        db.execSQL(sentencia);
    }

    //Si la base de datos cambia, se cambiará la versión y actualizarán los datos
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS Producto");
        db.execSQL(Producto);
        db.execSQL(sentencia);
    }

    public Cursor iniciarCursor(){

        SQLiteDatabase db = ProductoView.mibd.getReadableDatabase();

        Cursor cursor=db.rawQuery("select * from Producto",null);
        return cursor;
    }
}
