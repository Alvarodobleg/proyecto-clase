package notfireemblem;

import static com.sun.java.accessibility.util.AWTEventMonitor.addKeyListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.JPanel;


public class Game extends JPanel{
    
    int tamañoMapa=3;
    int numeroprotagonista=2;
    static int numeroselector=1;
    static char[][] mapa;
    Unidades[] unidad=new Unidades[numeroprotagonista];
    static Selector[] selector=new Selector[numeroselector];
    
    static boolean selectormove=true; 
    
    static int numerounidad=-1;
    
    public static void iniciarJuego(int tamañoMapa, char[][] mapa, Unidades [] unidad, int numeroprotagonista){
        
        
        //rellenar todo default
        for (int j = 0; j < mapa.length; j++) {
            for (int i = 0; i < mapa.length; i++) {
                mapa[i][j]='■';
            }
        }     
        
        //posicionar los elementos en el mapa aleatoriamente 
        while(numeroprotagonista!=0){
            int numAleatorio=(int)Math.floor(Math.random()*(tamañoMapa*tamañoMapa));
            for (int j = 0; j < mapa.length; j++) {
                for (int i = 0; i < mapa.length; i++) {
                    if(numAleatorio==i+j*tamañoMapa){
                        if(mapa[i][j]=='■'){
                            
                            if(numeroselector!=0){
                                numeroselector--;
                                selector[numeroselector]=new Selector(tamañoMapa,i,j);
                            }
                            else if(numeroprotagonista!=0){
                                numeroprotagonista--;
                                mapa[i][j]='U';
                                unidad[numeroprotagonista]=new Unidades(tamañoMapa,i,j,numeroprotagonista);
                            }

                        }
                    }
                }
            }
        }  
    }
    //Pintar el mapa
    @Override
    public void paint(Graphics g) {
        super.paint(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
        setBackground(Color.gray);
        
        g2d.setColor(Color.lightGray);
        for (int j = 0; j < tamañoMapa; j++) {
            for (int i = 0; i < tamañoMapa; i++) {
                g2d.drawRect(i*30, j*30, 30, 30);
            }
        }
        for (int i = 0; i < selector.length; i++) {
            selector[i].paint(g2d);
        }
        for (int i = 0; i < unidad.length; i++) {
            unidad[i].paint(g2d);
        }
        for (int i = 0; i < selector.length; i++) {
            selector[i].paint2(g2d);
        }
        
    }
    //Función encargada de mover las unidades
  
    //Función que mueve al selector
    public void moveselector() throws InterruptedException{ 
        //En principio devuelve el numerounidad que ha cogido de la unidad en caso de caer en una casilla con una unidad,
        //ese numero unidad al ser si o si mayor que -1 entrara en el if y moverá la unidad selecciondada (EN TEORIA)
        numerounidad = selector[0].moveselector(mapa,numerounidad,unidad);
        // Si no está este sleep threat peta NO QUITAR NIO PODÉS
        Thread.sleep(1);
        if(numerounidad!=-1){
           selectormove =false;
           
           unidad[numerounidad].move();
        }
        boolean scott=true;
        for (int i = 0; i < unidad.length; i++) {
            if(unidad[i].desplazado==false)
                scott=false;
        }
        if(scott==true)
            for (int i = 0; i < unidad.length; i++) {
                unidad[i].desplazado=false;
            }
    }
    
    public Game() {		
        mapa = new char[tamañoMapa][tamañoMapa];
        iniciarJuego(tamañoMapa,mapa,unidad,numeroprotagonista);
        //Teclas para el selector
        
        addKeyListener(new KeyListener() {
                        @Override
                        public void keyTyped(KeyEvent e) {
                        }

                        @Override
                        public void keyReleased(KeyEvent e) {                       
                                    //EN TEORIA el numerounidad que se obtiene de la función moverselector
                                    if( selectormove==true){
                                        selector[0].keyReleased(e);
                                    }else{
                                        unidad[numerounidad].keyReleased(e);
                                    }
                                    

                        }

                        @Override
                        public void keyPressed(KeyEvent e) {
                            if( selectormove==true){
                                selector[0].keyPressed(e);
                            }else{
                                unidad[numerounidad].keyPressed(e);
                            }
                        }
                     });
                setFocusable(true);
        }
    }

