package com.example.alvarog.FireEmblemWiki;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.annotation.Nullable;


/**
 * The type Mibasededatos.
 */
public class Mibasededatos extends SQLiteOpenHelper {

    /**
     * The Sql.
     */
//Utilizando sqlite creamos las dor tablas que utilizaremos en la aplicación
    String sql="CREATE TABLE Usuario (Nombre TEXT PRIMARY KEY , Pass TEXT)";
    /**
     * The Sql 2.
     */
    String sql2="CREATE TABLE Personajes (Nombrepj TEXT PRIMARY KEY , Imagen TEXT, lvl TEXT, hp TEXT, str TEXT, skl TEXT, spd TEXT, lck TEXT, def TEXT, res TEXT, chapter TEXT, class TEXT)";
    /**
     * The Sentencia.
     */
//Creamos una sentencia para insertar los datos que tendrá la tabla de personajes
    String sentencia="INSERT INTO Personajes (Nombrepj, Imagen, lvl, hp, str, skl, spd, lck, def, res, chapter, class) " +
            "VALUES('Roy','fullroy','1','18','5','5','7','4','5','0','1','Lord')," +
                  "('Marcus','fullmarcus','1','32','9','14','11','10','9','8','1','Paladín')," +
                  "('Alen','fullalen','1','21','7','4','6','3','6','0','1','Jinete')," +
                  "('Lance','fulllance','1','20','5','6','8','2','6','0','1','Jinete')," +
                  "('Wolt','fullwolt','1','18','4','4','5','2','4','0','1','Arquero')," +
                  "('Bors','fullbors','1','20','9','4','3','4','11','0','1','Caballero')," +
                  "('Ellen','fullellen','2','16','1','6','8','8','0','6','2','Clérigo')," +
                  "('Dieck','fulldieck','5','26','9','12','10','5','6','1','2','Mercenario')," +
                  "('Shanna','fullshanna','1','17','4','6','12','5','6','5','2','Jinete pegaso')," +
                  "('Chad','fullchad','1','16','3','3','10','4','2','0','3','Ladrón')," +
                  "('Lugh','fulllugh','1','16','4','5','6','5','3','5','3','Mago')," +
                  "('Clarine','fullclarine','1','15','2','5','9','8','2','5','4','Trovador')," +
                  "('Rutger','fullrutger','4','22','7','12','13','2','5','0','4','Mirmidón')," +
                  "('Dorothy','fulldorothy','3','19','5','6','6','3','4','2','6','Arquero')," +
                  "('Sue','fullsue','1','18','5','7','8','4','5','0','6','Nómada')," +
                  "('Zelots','fullzelots','1','35','10','12','13','5','11','7','7','Paladín')," +
                  "('Trec','fulltrec','4','25','8','6','7','5','8','0','7','Jinete')," +
                  "('Noah','fullnoah','7','27','8','7','9','6','7','1','7','Jinete')";

    /**
     * Instantiates a new Mibasededatos.
     *
     * @param context the context
     * @param name    the name
     * @param factory the factory
     * @param version the version
     */
//Constructor de la base de datos
    public Mibasededatos(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    //Elementos creados en  la base de datos,los cuales son las tablas y la sentencia que inserta los datos
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(sql);
        db.execSQL(sql2);
        db.execSQL(sentencia);
    }

    //Si la base de datos cambia, se cambiará la versión y actualizarán los datos
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS Usuario");
        db.execSQL(sql);
        db.execSQL("DROP TABLE IF EXISTS Personajes");
        db.execSQL(sql2);
        db.execSQL(sentencia);

    }

    /**
     * Insertar.
     * Función para crear un usuario en la tabla de Usuario llamado en la actividad de Registro
     * @param meteremail the meteremail
     * @param contrasena the contrasena
     */
    public void insertar(String meteremail, String contrasena){


        if (meteremail.length()>0 && contrasena.length()>0){
            SQLiteDatabase db = Main.miBD.getWritableDatabase();

            db.execSQL("INSERT INTO Usuario (Nombre, Pass) VALUES('"+ meteremail+"','" + contrasena+"' )");
            db.close();
        }
    }

    /**
     * Consulta boolean.
     * Consulta realizada en Main para ver si el usuario y contraseña existe en la base de datos
     * @param mail     the mail
     * @param password the password
     * @return the boolean
     */
    public boolean consulta(String mail, String password){

        SQLiteDatabase db = Main.miBD.getReadableDatabase();

        Cursor cursor=db.rawQuery("SELECT Nombre, Pass FROM Usuario WHERE Nombre = '"+mail+"' AND Pass = '"+password+"'",null);

        return cursor.moveToNext();
    }

    /**
     * Consulta registrado boolean.
     * Función utilizada la actividad Registro para comprobar si el usuario que se está introduciendo existe ya en la base de datos
     * @param mail the mail
     * @return the boolean
     */
    public boolean consultaRegistrado(String mail){

        SQLiteDatabase db = Main.miBD.getReadableDatabase();

        Cursor cursor=db.rawQuery("SELECT Nombre, Pass FROM Usuario WHERE Nombre = '"+mail+"'",null);

        return cursor.moveToNext();
    }
}
