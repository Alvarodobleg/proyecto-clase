package com.example.alvarog.FireEmblemWiki;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

/**
 * The type Registro.
 */
public class Registro extends AppCompatActivity {


    /**
     * The Meteremail.
     */
//Variables que se van a utilizar en esta actividad
    EditText meteremail;
    /**
     * The Contrasena.
     */
    EditText contrasena;
    /**
     * The Registrado.
     */
    boolean registrado=false;
    /**
     * The Username.
     */
    String username;
    /**
     * The Contrasenya.
     */
    String contrasenya;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);
        //Asignamos a cada variable los elementos que controlarán
        meteremail = (EditText) findViewById(R.id.entraemail);
        contrasena=(EditText) findViewById(R.id.entracontrasena);
    }

    /**
     * Meterdatos.
     * Toma los valores de los campos de email y contraseña y los registra en la base de datos en caso de que el usuario no exista ya en dicha base
     * @param papito the papito
     */
    public void meterdatos(View papito){
        //Introduce en las variables los datos que haya introducido el usuario en los campos de Usuario y contraseña
        username=meteremail.getText().toString();
        contrasenya=contrasena.getText().toString();
        //Boolean que tomará el valor true o false dependiendo de si la consulta indica que ese usuario ya existe
        registrado = Main.miBD.consultaRegistrado(username);
        //Al existir registrado=true y no se podrá incorporar ese usuario de nuevo a la base de datos
        if (registrado==true){
            Toast.makeText(this, "Usuario ya registrado", Toast.LENGTH_SHORT).show();
        }
        //El usuario no existe y se registra
        else{
            Main.miBD.insertar(username, contrasenya);
            Toast.makeText(this, "Usuario registrado correctamente", Toast.LENGTH_SHORT).show();
        }

    }

    /**
     * Alinicio.
     * Manda al usuario a la pantalla de inicio
     * @param view the view
     */

    public void alinicio (View view){

        Intent intent = new Intent(this, Main.class);
        Button editText = (Button) findViewById(R.id.Bvolver);
        startActivity(intent);
    }
}
