package com.example.alvarog.FireEmblemWiki;

import android.content.Intent;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

/**
 * The type Listapj.
 */
public class listapj extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listapj);

        //Variable que controla el fondo de esta actividad
        ConstraintLayout fondoinicio = findViewById(R.id.pjlayout);
        //Dependiendo del valor que tenga el boolean controlado por el togglebutton del Main se seleccionará un fondo
        if (Main.fondodianoche==false){
            fondoinicio.setBackgroundResource(R.drawable.dayfe);
        }
        else{
            fondoinicio.setBackgroundResource(R.drawable.nightfe);
        }
    }

    /**
     * Roy page.
     * enviará al usuario a la actividad PersonajeSeleccionado y mostrará ese personaje,
     *     * para ello al cambiar de actividad mandará un String como putExtra que contendrá el nombre del personaje seleccionado para así cargar
     *     * la siguiente actividad con los datos correctos
     * @param view the view
     */
    public void royPage(View view){

        Intent intent = new Intent(this, PersonajeSeleccionado.class);
        ImageButton editText = (ImageButton) findViewById(R.id.roybtn);
        intent.putExtra("miClave", "Roy");
        startActivity(intent);
    }

    /**
     * Marcus page.
     * enviará al usuario a la actividad PersonajeSeleccionado y mostrará ese personaje,
     *     * para ello al cambiar de actividad mandará un String como putExtra que contendrá el nombre del personaje seleccionado para así cargar
     *     * la siguiente actividad con los datos correctos
     * @param view the view
     */
    public void marcusPage(View view){

        Intent intent = new Intent(this, PersonajeSeleccionado.class);
        ImageButton editText = (ImageButton) findViewById(R.id.marcusbtn);
        intent.putExtra("miClave", "Marcus");
        startActivity(intent);
    }

    /**
     * Alen page.
     * enviará al usuario a la actividad PersonajeSeleccionado y mostrará ese personaje,
     *     * para ello al cambiar de actividad mandará un String como putExtra que contendrá el nombre del personaje seleccionado para así cargar
     *     * la siguiente actividad con los datos correctos
     * @param view the view
     */
    public void alenPage(View view){

        Intent intent = new Intent(this, PersonajeSeleccionado.class);
        ImageButton editText = (ImageButton) findViewById(R.id.alenbtn);
        intent.putExtra("miClave", "Alen");
        startActivity(intent);
    }

    /**
     * Lance page.
     * enviará al usuario a la actividad PersonajeSeleccionado y mostrará ese personaje,
     *     * para ello al cambiar de actividad mandará un String como putExtra que contendrá el nombre del personaje seleccionado para así cargar
     *     * la siguiente actividad con los datos correctos
     * @param view the view
     */
    public void lancePage(View view){

        Intent intent = new Intent(this, PersonajeSeleccionado.class);
        ImageButton editText = (ImageButton) findViewById(R.id.lancebtn);
        intent.putExtra("miClave", "Lance");
        startActivity(intent);
    }

    /**
     * Wolt page.
     * enviará al usuario a la actividad PersonajeSeleccionado y mostrará ese personaje,
     *     * para ello al cambiar de actividad mandará un String como putExtra que contendrá el nombre del personaje seleccionado para así cargar
     *     * la siguiente actividad con los datos correctos
     * @param view the view
     */
    public void woltPage(View view){

        Intent intent = new Intent(this, PersonajeSeleccionado.class);
        ImageButton editText = (ImageButton) findViewById(R.id.woltbtn);
        intent.putExtra("miClave", "Wolt");
        startActivity(intent);
    }

    /**
     * Bors page.
     * enviará al usuario a la actividad PersonajeSeleccionado y mostrará ese personaje,
     *     * para ello al cambiar de actividad mandará un String como putExtra que contendrá el nombre del personaje seleccionado para así cargar
     *     * la siguiente actividad con los datos correctos
     * @param view the view
     */
    public void borsPage(View view){

        Intent intent = new Intent(this, PersonajeSeleccionado.class);
        ImageButton editText = (ImageButton) findViewById(R.id.borsbtn);
        intent.putExtra("miClave", "Bors");
        startActivity(intent);
    }

    /**
     * Ellen page.
     * enviará al usuario a la actividad PersonajeSeleccionado y mostrará ese personaje,
     *     * para ello al cambiar de actividad mandará un String como putExtra que contendrá el nombre del personaje seleccionado para así cargar
     *     * la siguiente actividad con los datos correctos
     * @param view the view
     */
    public void ellenPage(View view){

        Intent intent = new Intent(this, PersonajeSeleccionado.class);
        ImageButton editText = (ImageButton) findViewById(R.id.ellenbtn);
        intent.putExtra("miClave", "Ellen");
        startActivity(intent);
    }

    /**
     * Dieck page.
     * enviará al usuario a la actividad PersonajeSeleccionado y mostrará ese personaje,
     *     * para ello al cambiar de actividad mandará un String como putExtra que contendrá el nombre del personaje seleccionado para así cargar
     *     * la siguiente actividad con los datos correctos
     * @param view the view
     */
    public void dieckPage(View view){

        Intent intent = new Intent(this, PersonajeSeleccionado.class);
        ImageButton editText = (ImageButton) findViewById(R.id.dieckbtn);
        intent.putExtra("miClave", "Dieck");
        startActivity(intent);
    }

    /**
     * Shanna page.
     * enviará al usuario a la actividad PersonajeSeleccionado y mostrará ese personaje,
     *     * para ello al cambiar de actividad mandará un String como putExtra que contendrá el nombre del personaje seleccionado para así cargar
     *     * la siguiente actividad con los datos correctos
     * @param view the view
     */
    public void shannaPage(View view){

        Intent intent = new Intent(this, PersonajeSeleccionado.class);
        ImageButton editText = (ImageButton) findViewById(R.id.shannabtn);
        intent.putExtra("miClave", "Shanna");
        startActivity(intent);
    }

    /**
     * Chad page.
     * enviará al usuario a la actividad PersonajeSeleccionado y mostrará ese personaje,
     *     * para ello al cambiar de actividad mandará un String como putExtra que contendrá el nombre del personaje seleccionado para así cargar
     *     * la siguiente actividad con los datos correctos
     * @param view the view
     */
    public void chadPage(View view){

        Intent intent = new Intent(this, PersonajeSeleccionado.class);
        ImageButton editText = (ImageButton) findViewById(R.id.chadbtn);
        intent.putExtra("miClave", "Chad");
        startActivity(intent);
    }

    /**
     * Lugh page.
     * enviará al usuario a la actividad PersonajeSeleccionado y mostrará ese personaje,
     *     * para ello al cambiar de actividad mandará un String como putExtra que contendrá el nombre del personaje seleccionado para así cargar
     *     * la siguiente actividad con los datos correctos
     * @param view the view
     */
    public void lughPage(View view){

        Intent intent = new Intent(this, PersonajeSeleccionado.class);
        ImageButton editText = (ImageButton) findViewById(R.id.lughbtn);
        intent.putExtra("miClave", "Lugh");
        startActivity(intent);
    }

    /**
     * Clarine page.
     * enviará al usuario a la actividad PersonajeSeleccionado y mostrará ese personaje,
     *     * para ello al cambiar de actividad mandará un String como putExtra que contendrá el nombre del personaje seleccionado para así cargar
     *     * la siguiente actividad con los datos correctos
     * @param view the view
     */
    public void clarinePage(View view){

        Intent intent = new Intent(this, PersonajeSeleccionado.class);
        ImageButton editText = (ImageButton) findViewById(R.id.clarinebtn);
        intent.putExtra("miClave", "Clarine");
        startActivity(intent);
    }

    /**
     * Rutger page.
     * enviará al usuario a la actividad PersonajeSeleccionado y mostrará ese personaje,
     *     * para ello al cambiar de actividad mandará un String como putExtra que contendrá el nombre del personaje seleccionado para así cargar
     *     * la siguiente actividad con los datos correctos
     * @param view the view
     */
    public void rutgerPage(View view){

        Intent intent = new Intent(this, PersonajeSeleccionado.class);
        ImageButton editText = (ImageButton) findViewById(R.id.rutgerbtn);
        intent.putExtra("miClave", "Rutger");
        startActivity(intent);
    }

    /**
     * Dorothy page.
     * enviará al usuario a la actividad PersonajeSeleccionado y mostrará ese personaje,
     *     * para ello al cambiar de actividad mandará un String como putExtra que contendrá el nombre del personaje seleccionado para así cargar
     *     * la siguiente actividad con los datos correctos
     * @param view the view
     */
    public void dorothyPage(View view){

        Intent intent = new Intent(this, PersonajeSeleccionado.class);
        ImageButton editText = (ImageButton) findViewById(R.id.dorothybtn);
        intent.putExtra("miClave", "Dorothy");
        startActivity(intent);
    }

    /**
     * Sue page.
     * enviará al usuario a la actividad PersonajeSeleccionado y mostrará ese personaje,
     *     * para ello al cambiar de actividad mandará un String como putExtra que contendrá el nombre del personaje seleccionado para así cargar
     *     * la siguiente actividad con los datos correctos
     * @param view the view
     */
    public void suePage(View view){

        Intent intent = new Intent(this, PersonajeSeleccionado.class);
        ImageButton editText = (ImageButton) findViewById(R.id.suebtn);
        intent.putExtra("miClave", "Sue");
        startActivity(intent);
    }

    /**
     * Zelots page.
     * enviará al usuario a la actividad PersonajeSeleccionado y mostrará ese personaje,
     *     * para ello al cambiar de actividad mandará un String como putExtra que contendrá el nombre del personaje seleccionado para así cargar
     *     * la siguiente actividad con los datos correctos
     * @param view the view
     */
    public void zelotsPage(View view){

        Intent intent = new Intent(this, PersonajeSeleccionado.class);
        ImageButton editText = (ImageButton) findViewById(R.id.zelotsbtn);
        intent.putExtra("miClave", "Zelots");
        startActivity(intent);
    }

    /**
     * Trec page.
     * enviará al usuario a la actividad PersonajeSeleccionado y mostrará ese personaje,
     *     * para ello al cambiar de actividad mandará un String como putExtra que contendrá el nombre del personaje seleccionado para así cargar
     *     * la siguiente actividad con los datos correctos
     * @param view the view
     */
    public void trecPage(View view){

        Intent intent = new Intent(this, PersonajeSeleccionado.class);
        ImageButton editText = (ImageButton) findViewById(R.id.trecbtn);
        intent.putExtra("miClave", "Trec");
        startActivity(intent);
    }

    /**
     * Noah page.
     * enviará al usuario a la actividad PersonajeSeleccionado y mostrará ese personaje,
     *     * para ello al cambiar de actividad mandará un String como putExtra que contendrá el nombre del personaje seleccionado para así cargar
     *     * la siguiente actividad con los datos correctos
     * @param view the view
     */
    public void noahPage(View view){

        Intent intent = new Intent(this, PersonajeSeleccionado.class);
        ImageButton editText = (ImageButton) findViewById(R.id.noajbtn);
        intent.putExtra("miClave", "Noah");
        startActivity(intent);
    }
}
