package com.example.alvarog.FireEmblemWiki;

import android.content.res.Resources;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.drawable.Drawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * The type Personaje seleccionado.
 */
public class PersonajeSeleccionado extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_personaje_seleccionado);

        //Declara todos los TextViews que se necesitarán para poder mostrar los datos de los personajes y les asigna el elemento donde se mostrará
        TextView nivel = (TextView) findViewById(R.id.pjnivel);
        TextView vida = (TextView) findViewById(R.id.pjvida);
        TextView fuerza = (TextView) findViewById(R.id.pjfuerza);
        TextView habilidad = (TextView) findViewById(R.id.pjhabilidad);
        TextView velocidad = (TextView) findViewById(R.id.pjvelocidad);
        TextView suerte = (TextView) findViewById(R.id.pjsuerte);
        TextView defensa = (TextView) findViewById(R.id.pjdefensa);
        TextView resistencia = (TextView) findViewById(R.id.pjresistencia);
        TextView capitulo = (TextView) findViewById(R.id.pjcapitulo);
        TextView clase = (TextView) findViewById(R.id.pjclase);
        TextView nombre = (TextView) findViewById(R.id.pjname);

        //Guardamos en el String personaje el putExtra con el String del nombre que se ha traido de la actividad listapj al pulsar uno de los botones
        String personaje= getIntent().getStringExtra("miClave");
        /*Se crea una variable de tipo SQLiteDatabase para poder manejar la base de datos y se realiza la consulta de abajo en la que busca en la tabla
         Personajes el nombre del personaje que se envió desde la actividad listapj*/
        SQLiteDatabase db = Main.miBD.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM Personajes WHERE Nombrepj = '"+ personaje +"'", null);

        //Se situa el cursor en el primer y único resultado de la consulta y asigna los valores de cada campo a su respectiva variable para poder ser mostrados
        cursor.moveToFirst();
        nombre.setText(cursor.getString(0));
        nivel.setText(cursor.getString(2));
        vida.setText(cursor.getString(3));
        fuerza.setText(cursor.getString(4));
        habilidad.setText(cursor.getString(5));
        velocidad.setText(cursor.getString(6));
        suerte.setText(cursor.getString(7));
        defensa.setText(cursor.getString(8));
        resistencia.setText(cursor.getString(9));
        capitulo.setText(cursor.getString(10));
        clase.setText(cursor.getString(11));

        //Esta serie de líneas son los pasos a seguir para transformar el String que contiene el nombre de la imagen de la base de datos en un elemento drawable
        ImageView img =findViewById(R.id.pjdisplay);
        //Asignamos al String imagen su campo correspondiente de la consulta
        String imagen = cursor.getString(1);
        Resources res = getResources();
        int resID = res.getIdentifier(imagen , "drawable", getPackageName());
        Drawable drawable = res.getDrawable(resID );
        img.setImageDrawable(drawable );
    }
}
