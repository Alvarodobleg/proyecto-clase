package com.example.alvarog.FireEmblemWiki;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Handler;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

/**
 * The type Inicionext.
 */
public class inicionext extends AppCompatActivity {

    /**
     * The Cancion.
     */
    static MediaPlayer cancion;
    /**
     * The Cancionsonando.
     */
    static boolean cancionsonando=false;
    /**
     * The Double back to exit pressed once.
     */
    boolean doubleBackToExitPressedOnce = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inicionext);

        cancion = MediaPlayer.create(inicionext.this,R.raw.taskathand);
        cancion.start();
        cancionsonando=true;

        //Variable que controla el fondo de esta actividad
        ConstraintLayout fondoinicio = findViewById(R.id.inicioLayout);
        //Dependiendo del valor que tenga el boolean controlado por el togglebutton del Main se seleccionará un fondo
        if (Main.fondodianoche==false){
            fondoinicio.setBackgroundResource(R.drawable.dayfe);
        }
        else{
            fondoinicio.setBackgroundResource(R.drawable.nightfe);
        }
    }

    /**
     * Alinicio.
     * Al pulsar el botón salir devuelve al usuario a la pantalla de inicio
     * @param view the view
     */
    public void alinicio (View view){

        Intent intent = new Intent(this, Main.class);
        Button editText = (Button) findViewById(R.id.pafuera);
        cancion.release();
        startActivity(intent);
    }

    /**
     * Apersonaje.
     * Al pulsar el botón personajes manda al usuario a la pantalla de selección de personaje
     * @param view the view
     */
    public void apersonaje (View view){

        Intent intent = new Intent(this, listapj.class);
        Button editText = (Button) findViewById(R.id.personajelist);
        startActivity(intent);
    }

    //Metodo que obliga al usuario pulsar dos veces el boton de volver para pasar a la pagina de login, esto tambien para la musica.
    @Override
    public void onBackPressed() {
        if (doubleBackToExitPressedOnce) {
            super.onBackPressed();

            cancion.release();
            return;
        }

        this.doubleBackToExitPressedOnce = true;
        Toast.makeText(this, "Pulsa el boton de volver de nuevo para salir al menu", Toast.LENGTH_SHORT).show();

        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
                doubleBackToExitPressedOnce=false;
            }
        }, 2000);
    }
}
