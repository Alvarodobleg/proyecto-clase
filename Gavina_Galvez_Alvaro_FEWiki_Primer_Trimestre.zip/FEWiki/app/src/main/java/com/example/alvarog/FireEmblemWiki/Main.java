package com.example.alvarog.FireEmblemWiki;

import android.content.Intent;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.ToggleButton;

import static android.provider.AlarmClock.EXTRA_MESSAGE;
import static com.example.alvarog.FireEmblemWiki.inicionext.cancion;
import static com.example.alvarog.FireEmblemWiki.inicionext.cancionsonando;

/**
 * The type Main.
 */
public class Main extends AppCompatActivity {
    /**
     * The constant miBD.
     */
//Variable de la clase Mibasededatos que crea la base de datos que utilizaremos en toda la aplicación mientras corresponda
    public static Mibasededatos miBD;
    /**
     * The Usuario.
     */
//Variables que se utilizarán en esta Activity
    EditText usuario;
    /**
     * The Pass.
     */
    EditText pass;
    /**
     * The Usuario str.
     */
    String usuarioStr;
    /**
     * The Pass str.
     */
    String passStr;
    /**
     * The Fondo.
     */
    ConstraintLayout fondo;
    /**
     * The Logeado.
     */
    boolean logeado=false;
    /**
     * The Fondodianoche.
     */
    static boolean fondodianoche=true;

    //En  OnCreate se crea la instancia y se inicializan los elemento que se van a utilizar dentro de esta pantalla
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lapractica_main);
        //Asignamos a las variables que elementos de la pantalla van a utilizar
        usuario = (EditText) findViewById(R.id.usuarioMain);
        pass=(EditText) findViewById(R.id.passMain);
        //Inicializamos la base de datos dánsole un nombre y una versión
        miBD = new Mibasededatos(this, "otraBD", null, 6);

        /*El togglebutton que se encarga de cambiar el fondo, cambiando el boolean fondodianoche para indicar que fondo tendrá la aplicación.
        * cada vez que se pulsa el botón el boolean cambiará su valor*/
        ToggleButton toggle = (ToggleButton) findViewById(R.id.toggleButton2);
        toggle.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                fondo = findViewById(R.id.LayoutMain);
                if (isChecked) {
                    fondodianoche=false;
                    fondo.setBackgroundResource(R.drawable.dayfe);
                } else {
                    fondodianoche=true;
                    fondo.setBackgroundResource(R.drawable.nightfe);
                }
            }
        });

        //Estas líneas inicializan el fondo en el OnCreate para cuadrarlo con el indicado en el togglebutton
        fondo = findViewById(R.id.LayoutMain);

        if (Main.fondodianoche==false){
            fondo.setBackgroundResource(R.drawable.dayfe);
        }
        else{
            fondo.setBackgroundResource(R.drawable.nightfe);
        }

        if(cancionsonando==true){
            cancion.release();
            cancionsonando=false;
        }

    }

    /**
     * Alregistro.
     * Método que manda al usuario a la actividad Registro al pulsar el botón registro
     * @param view the view
     */
    public void alregistro (View view){

        Intent intent = new Intent(this,Registro.class);
        Button editText = (Button) findViewById(R.id.Bregistro);
        String message = editText.getText().toString();
        intent.putExtra(EXTRA_MESSAGE, message);
        startActivity(intent);
    }

    /**
     * Logearse.
     *     Cuando se introducen unos datos en los campos de usuario y contraseña al pulsar el botón LOGIN pasará el valor en String de
     *     los campos a la función y comparará el usuario y la contraseña con los que hay guardados en la base de datos, en caso de que
     *     encuentre estos datos en la base de datos pasará al usuario a la actividad  iniciotext, si los datos no están correctamente introducidos se indicará con un popup
     * @param view the view
     */
    public void logearse(View view){

        usuarioStr=usuario.getText().toString();
        passStr=pass.getText().toString();
        logeado=miBD.consulta(usuarioStr,passStr);

        if (logeado==true){

            Intent intent= new Intent(this,inicionext.class);
            startActivity(intent);
        }
        else{
            Toast.makeText(this, "Datos incorrectos.", Toast.LENGTH_SHORT).show();
        }
    }


}
