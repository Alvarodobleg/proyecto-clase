package notfireemblem;

import java.awt.Color;
import java.awt.Graphics2D;


public class Enemigos {
    
    int movilidad;
    int movilidadGuardada;
    boolean movimiento=false;    
    int x=0;
    int y=0;
    int xg;
    int yg;
    int tamañoMapa;
    int numeroenemigo;
    int posicion;
    boolean desplazado;
    
    int ataque=5;

    int dañohecho;
    int dañomaximo=0;
    
    int vida=100;
    
    public Enemigos(int tamañoMapa,int x, int y,int numeroenemigo,int posicion){
        
        this.movilidad=7;
        this.movilidadGuardada=movilidad;
        this.tamañoMapa=tamañoMapa;
        this.x=x*30;
        this.y=y*30;
        this.xg=this.x/30;
        this.yg=this.y/30;
        
        this.numeroenemigo=numeroenemigo;
        
        this.desplazado=false;
        
        this.posicion=posicion;
    }
    
    
    public void paint(Graphics2D g) {
        
        if(movimiento==true && Game.numeroenemigos!=-1){
            g.setColor(Color.red);
            g.drawRect(x, y, 30, 30);
            for (int i = 1; i <= movilidad; i++) {
                g.drawRect(x+(i*30), y, 30, 30);
                g.drawRect(x, y+(i*30), 30, 30);
                g.drawRect(x-(i*30), y, 30, 30);
                g.drawRect(x, y-(i*30), 30, 30);
            }
            
            g.setColor(Color.darkGray);
            g.fillOval(x+1, y+1, 29, 29);
            g.setColor(Color.red);
            g.fillOval(x+1, y+1-5, 29, 29);            
        }
        else if (movimiento==true && Game.numeroenemigos==-1 ) {
                g.setColor(Color.red);
                g.fillOval(x, y, 30, 30);
            }
        
        else{
            g.setColor(Color.red);
            g.fillOval(x+1, y+1, 29, 29);
            //Cuando desplazado(que indica que se ha movido) es true, se pone color negro para confirmar visualmente que se ha movido
            /*if (desplazado==true) {
                g.setColor(Color.BLACK);
                g.fillOval(x+1, y+1, 29, 29);
            }*/
        }
    }
    
    public void move(Unidades [] unidad, Mapa[] mapa){
        
        /*Estas variables xresta,yresta calculan la distancia en ese eje que hay desde la posicion de enemigo a la de unidad
        la suma de ambas da el movnecesario para llegar a la posición de la unidad
        el array de boolean alcanzable tomará valor true para las unidades que pueden alcanzar, después de esto decidirá 
        a por cual de ellos irá*/
        int xresta, yresta, movnecesario;
        boolean [] alcanzable = new boolean [unidad.length];
        //El objetivo tendrá la posición a la que se atacará una vez decidido y calculado si se le puede atacar y si es el elegido para ser atacado
        int objetivo=-1;
        //
        int casillaataque=-1;
        for (int i = 0; i < unidad.length; i++) {
            alcanzable[i]=false;
        }
        //Este for calcula que unidades son alcanzables, las que lo son son marcadas como true en la posición que ocupa esa unidad en su propio array 
        //SEGURAMENTE TIDAS LAS X,Y SE TENGAN QUE DIVIDIR ENTRE 30 PORQUE TIENEN LAS COORDENADAS DEL DIBUJO MULTIPLICADO POR LOS 30 PIXELES, O PROBAR CON XG,YG
        for (int i = 0; i < unidad.length; i++) {
            if (this.xg>unidad[i].xg) {
                xresta=this.xg-unidad[i].xg;
            }
            else{
                xresta=unidad[i].xg-this.xg;
            }
            if (this.yg>unidad[i].yg) {
                yresta=this.yg-unidad[i].yg;
            }
            else{
                yresta=unidad[i].yg-this.yg;
            }
            movnecesario=xresta+yresta;
            if ((this.movilidad-1)>=movnecesario) {
                alcanzable[i]=true;
            }
        }
        //Este for decide a cual de las unidades que puede alcanzar va a atacar (PUEDE QUE ESTE FOR HAYA QUE METERSO EN UNA FUNCIÓN A PARTE)
        for (int i = 0; i < unidad.length; i++) {
            if (alcanzable[i]==true) {
                /*la idea aquí es introducir un algoritmo que calcule por ejemplo cuanto daño le puede hacer a cada una de las unidades que puede alcanzar
                y tomar como objetivo a aquella a la que le haga más daño, si le hace el mismo daño a varias unidades el objetivo se decidirá con un random*/
                dañohecho=this.ataque-unidad[i].defensa;
                if (dañohecho>=dañomaximo) {
                    objetivo=i;
                    dañomaximo=dañohecho;
                }
                
            }
        }
        //Este for comprueba las cuatro casillas adyacentes al objetivo para ver en cual de las 4 va a atacar
        if (objetivo!=-1) {
            
            for (int i = 0; i < 4; i++) {
                if (i==0) {
                    if (this.xg>unidad[objetivo].xg+1) {
                        xresta=this.xg-unidad[objetivo].xg+1;
                    }
                    else{
                        xresta=unidad[objetivo].xg+1-this.xg;
                    }
                    if (this.yg>unidad[objetivo].yg) {
                        yresta=this.yg-unidad[objetivo].yg;
                    }
                    else{
                        yresta=unidad[objetivo].yg-this.yg;
                    }
                    movnecesario=xresta+yresta;
                    //si tiene la movilidad necesaria para llegar a la casilla
                    if ((this.movilidad)>=movnecesario) {
                        //Ver que posición en el mapa ocupa esta x,y que estamos observando
                        for (int j = 0; j < mapa.length; j++) {
                            if (mapa[j].x==unidad[objetivo].xg+1 && mapa[j].y==unidad[objetivo].yg) {
                                /*Cuando encuentre la posición donde x,y coinciden con lo que buscamos ver si la casilla está vacia
                                en ese caso guardarla para que el enemigo se mueva allí*/
                                if (mapa[j].elemento=='■') {                                    
                                casillaataque=j;
                                }
                            }
                        }
                    }
                }
                else if (i==1) {
                    if (this.xg>unidad[objetivo].xg-1) {
                        xresta=this.xg-unidad[objetivo].xg-1;
                    }
                    else{
                        xresta=unidad[objetivo].xg-1-this.xg;
                    }
                    if (this.yg>unidad[objetivo].yg) {
                        yresta=this.yg-unidad[objetivo].yg;
                    }
                    else{
                        yresta=unidad[objetivo].yg-this.yg;
                    }
                    movnecesario=xresta+yresta;
                    if ((this.movilidad)>=movnecesario) {
                        //Ver que posición en el mapa ocupa esta x,y que estamos observando
                        for (int j = 0; j < mapa.length; j++) {
                            if (mapa[j].x==unidad[objetivo].xg-1 && mapa[j].y==unidad[objetivo].yg) {
                                /*Cuando encuentre la posición donde x,y coinciden con lo que buscamos ver si la casilla está vacia
                                en ese caso guardarla para que el enemigo se mueva allí*/
                                if (mapa[j].elemento=='■') {                                    
                                casillaataque=j;
                                }
                            }
                        }
                    }
                }
                else if (i==2) {
                    if (this.xg>unidad[objetivo].xg) {
                        xresta=this.xg-unidad[objetivo].xg;
                    }
                    else{
                        xresta=unidad[objetivo].xg-this.xg;
                    }
                    if (this.yg>unidad[objetivo].yg+1) {
                        yresta=this.yg-unidad[objetivo].yg+1;
                    }
                    else{
                        yresta=unidad[objetivo].yg+1-this.yg;
                    }
                    movnecesario=xresta+yresta;
                    if ((this.movilidad)>=movnecesario) {
                        //Ver que posición en el mapa ocupa esta x,y que estamos observando
                        for (int j = 0; j < mapa.length; j++) {
                            if (mapa[j].x==unidad[objetivo].xg && mapa[j].y==unidad[objetivo].yg+1) {
                                /*Cuando encuentre la posición donde x,y coinciden con lo que buscamos ver si la casilla está vacia
                                en ese caso guardarla para que el enemigo se mueva allí*/
                                if (mapa[j].elemento=='■') {                                    
                                casillaataque=j;
                                }
                            }
                        }
                    }
                }
                else if (i==3) {
                    if (this.xg>unidad[objetivo].xg) {
                        xresta=this.xg-unidad[objetivo].xg;
                    }
                    else{
                        xresta=unidad[objetivo].xg-this.xg;
                    }
                    if (this.yg>unidad[objetivo].yg-1) {
                        yresta=this.yg-unidad[objetivo].yg-1;
                    }
                    else{
                        yresta=unidad[objetivo].yg-1-this.yg;
                    }
                    movnecesario=xresta+yresta;
                    if ((this.movilidad)>=movnecesario) {
                        //Ver que posición en el mapa ocupa esta x,y que estamos observando
                        for (int j = 0; j < mapa.length; j++) {
                            if (mapa[j].x==unidad[objetivo].xg && mapa[j].y==unidad[objetivo].yg-1) {
                                /*Cuando encuentre la posición donde x,y coinciden con lo que buscamos ver si la casilla está vacia
                                en ese caso guardarla para que el enemigo se mueva allí*/
                                if (mapa[j].elemento=='■') {                                    
                                casillaataque=j;
                                }
                            }
                        }
                    }
                }
            }
        }
        //AHORA QUE TENGO LA CASILLAATAQUE Y LA UNIDAD OBJETIVO DEBO MOVER EL ELEMENTO TANTO EN EL MAPA COMO VISUALMENTE 
        if (casillaataque!=-1 && objetivo!=-1) {
            movimiento=true;
            xg=mapa[casillaataque].x;
            yg=mapa[casillaataque].y;
            x=xg*30;
            y=yg*30;
            
            mapa[casillaataque].elemento='E';
            mapa[this.posicion].elemento='■';
            this.posicion=casillaataque;
            System.out.println("ENTRA EN FUNCION");
            //No tengo claro si es necesario pero lo dejo para tenerlo en cuenta por si acaso Game.numeroenemigos=-1;
            movimiento=false;
            //desplazado=true;
            /*HAY QUE JUGAR CON EL VALOR DE MOVIMIENTO Y DESPLAZADO CUANDO CORRESPONDA PARA QUE SE HAGA CORRECTAMENTE
            SEGURAMENTE HAYA QUE DECIRLE LOS MOVIMIENTO DE X,Y MULTIPLICADO POR 30 O ALGO*/
        }
    }
    
}
