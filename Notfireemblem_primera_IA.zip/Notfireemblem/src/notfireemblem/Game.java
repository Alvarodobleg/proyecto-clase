package notfireemblem;

import static com.sun.java.accessibility.util.AWTEventMonitor.addKeyListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.JPanel;


public class Game extends JPanel{
    
    int tamañoMapa=5;
    int numeroprotagonista=2;
    static int numeroenemigos=4;
    static int casillaMapa=0;
    static int numeroselector=1;
    static Mapa[] mapa;
    static Enemigos[] enemigo=new Enemigos[numeroenemigos];
    Unidades[] unidad=new Unidades[numeroprotagonista];
    static Selector[] selector=new Selector[numeroselector];
    //Boolean que gestiona si el key listener irá a la unidad o al selector
    static boolean selectormove=true; 
    //Valor devuelto en la función mover selector que determina si el selectr a caido en una casilla de unidad
    static int numerounidad=-1;
    
    //esta variable determina quien se moverá, si es U las unidades y si es E los enemigos
    char turno='U';
    
    public static void iniciarJuego(int tamañoMapa, Mapa [] mapa, Unidades [] unidad, int numeroprotagonista){
        
        
        //rellenar todo default
        for (int j = 0; j < tamañoMapa; j++) {
            for (int i = 0; i < tamañoMapa; i++) {
                mapa[casillaMapa] = new Mapa();
                mapa[casillaMapa].x=i;
                mapa[casillaMapa].y=j;
                mapa[casillaMapa].elemento='■';
                //no esta volviendo a tomar el valor 0 aún
                casillaMapa++;
            }
        }     
        
        //posicionar los elementos en el mapa aleatoriamente 
        //Lo último que debe escribirse son las unidades
        while(numeroprotagonista!=0){
            int numAleatorio=(int)Math.floor(Math.random()*(tamañoMapa*tamañoMapa));
            for (int j = 0; j < tamañoMapa; j++) {
                for (int i = 0; i < tamañoMapa; i++) {
                    if(numAleatorio==i+j*tamañoMapa){
                        if(mapa[numAleatorio].elemento=='■'){
                            
                            if(numeroselector!=0){
                                numeroselector--;
                                //si algo falla mirar si  la x,y no están invertidos
                                selector[numeroselector]=new Selector(tamañoMapa,mapa[numAleatorio].x,mapa[numAleatorio].y,numAleatorio);
                            }
                            else if(numeroenemigos!=0){
                                numeroenemigos--;
                                mapa[numAleatorio].elemento='E';
                                enemigo[numeroenemigos]=new Enemigos(tamañoMapa,mapa[numAleatorio].x,mapa[numAleatorio].y,numeroenemigos,numAleatorio);
                            }
                            else if(numeroprotagonista!=0){
                                numeroprotagonista--;
                                mapa[numAleatorio].elemento='U';
                                unidad[numeroprotagonista]=new Unidades(tamañoMapa,mapa[numAleatorio].x,mapa[numAleatorio].y,numeroprotagonista,numAleatorio);
                            }
                            
                        }
                    }
                }
            }
        }  
    }
    //Pintar el mapa
    @Override
    public void paint(Graphics g) {
        super.paint(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
        setBackground(Color.gray);
        
        g2d.setColor(Color.lightGray);
        for (int j = 0; j < tamañoMapa; j++) {
            for (int i = 0; i < tamañoMapa; i++) {
                g2d.drawRect(i*30, j*30, 30, 30);
            }
        }
        for (int i = 0; i < selector.length; i++) {
            selector[i].paint(g2d);
        }
        for (int i = 0; i < unidad.length; i++) {
            unidad[i].paint(g2d);
        }
        for (int i = 0; i < enemigo.length; i++) {
            enemigo[i].paint(g2d);
        }
        for (int i = 0; i < selector.length; i++) {
            selector[i].paint2(g2d);
        }
        
    }
    //Función que mueve al selector
    public void moveselector() throws InterruptedException{
        boolean scott=true;
        if(turno=='U'){
            //En principio devuelve el numerounidad que ha cogido de la unidad en caso de caer en una casilla con una unidad,
            //ese numero unidad al ser si o si mayor que -1 entrara en el if y moverá la unidad selecciondada
            numerounidad = selector[0].moveselector(mapa,numerounidad,unidad);
            // Si no está este sleep threat peta NO QUITAR NIO PODÉS
            Thread.sleep(1);
            if(numerounidad!=-1){
               selectormove =false;

               unidad[numerounidad].move();
            }
            //Variable que sirve para ver si se han movido todas las unidades
            
            //Si algún desplazado de cualquier unidad está en false, lo que significa que no se ha movido, scott==falso
            for (int i = 0; i < unidad.length; i++) {
                if(unidad[i].desplazado==false)
                    scott=false;
            }
            //Cuando scott sea verdadero significa que todas las unidads se han movido por lo tanto es el turno del enemigo
            if(scott==true){
                turno='E';
            }
        }
        //despues de moverse todas las unidades es el turno del enemigo
        else if(turno=='E'){
            //system.out comprobante
            System.out.println("ENEMIGO");
            for (int i = 0; i < enemigo.length; i++) {
                
                enemigo[i].move(unidad,mapa);
            }
            //Al terminar de moverse el enemigo se reiniciará el valor desplazado de todas las unidades para que se pedan volver a mover
            if(scott==true)
                for (int i = 0; i < unidad.length; i++) {
                    unidad[i].desplazado=false;
            }
            turno='U';
        }
    }
    
    public Game() {		
        mapa = new Mapa[tamañoMapa*tamañoMapa];
        iniciarJuego(tamañoMapa,mapa,unidad,numeroprotagonista);
        //Teclas para el selector
        
        addKeyListener(new KeyListener() {
                        @Override
                        public void keyTyped(KeyEvent e) {
                        }

                        @Override
                        public void keyReleased(KeyEvent e) {                       
                                    //Si el selectormove==true se moverá el selector pero si está en falso el keylistener pasará a la unidad seleccionada 
                                    //en la casilla de posición numerounidad (numerounidad cambia en la función moverselector)
                                    if( selectormove==true){
                                        selector[0].keyReleased(e);
                                    }else{
                                        unidad[numerounidad].keyReleased(e);
                                    }
                                    

                        }

                        @Override
                        public void keyPressed(KeyEvent e) {
                            if( selectormove==true){
                                selector[0].keyPressed(e);
                            }else{
                                unidad[numerounidad].keyPressed(e);
                            }
                        }
                     });
                setFocusable(true);
        }
    }

